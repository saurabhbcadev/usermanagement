User Management System
Created by- Saurabh Kumar - s9955037382@gmail.com 	7488944009

Instruction -
1. download zip then unzip and paste all files onto the server folder such as htdocs.
2. use 'test.sql' to import the database and its table along with its data.
3. modify 'connect.php' for database connection.
4. modify 'sendmail.php' for sending mail to the user email. 
5. modify 'sendmail.php' Line No 21 verification link according to your servername and foldername.
6. open index.php as homepage


REFERENCES: Used or get help while developing this system.
1. w3school-MySql Database For PDO - https://www.w3schools.com/php/php_mysql_connect.asp
2. Youtube - For sending Email - https://www.youtube.com/watch?v=9tD8lA9foxw
3. PHPMailer- for sending Email - https://github.com/PHPMailer/PHPMailer


